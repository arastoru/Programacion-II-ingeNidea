﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OperacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaProductosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EntradaInventarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistroProductosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.COnsultasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaInventarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBoxLogo = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBoxLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OperacionesToolStripMenuItem, Me.RegistroToolStripMenuItem, Me.COnsultasToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 3, 0, 3)
        Me.MenuStrip1.Size = New System.Drawing.Size(679, 34)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OperacionesToolStripMenuItem
        '
        Me.OperacionesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalidaProductosToolStripMenuItem, Me.EntradaInventarioToolStripMenuItem})
        Me.OperacionesToolStripMenuItem.Name = "OperacionesToolStripMenuItem"
        Me.OperacionesToolStripMenuItem.Size = New System.Drawing.Size(85, 22)
        Me.OperacionesToolStripMenuItem.Text = "Operaciones"
        '
        'SalidaProductosToolStripMenuItem
        '
        Me.SalidaProductosToolStripMenuItem.Name = "SalidaProductosToolStripMenuItem"
        Me.SalidaProductosToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.SalidaProductosToolStripMenuItem.Text = "Salida productos"
        '
        'EntradaInventarioToolStripMenuItem
        '
        Me.EntradaInventarioToolStripMenuItem.Name = "EntradaInventarioToolStripMenuItem"
        Me.EntradaInventarioToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.EntradaInventarioToolStripMenuItem.Text = "Entrada Inventario"
        '
        'RegistroToolStripMenuItem
        '
        Me.RegistroToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistroProductosToolStripMenuItem})
        Me.RegistroToolStripMenuItem.Name = "RegistroToolStripMenuItem"
        Me.RegistroToolStripMenuItem.Size = New System.Drawing.Size(62, 22)
        Me.RegistroToolStripMenuItem.Text = "Registro"
        '
        'RegistroProductosToolStripMenuItem
        '
        Me.RegistroProductosToolStripMenuItem.Name = "RegistroProductosToolStripMenuItem"
        Me.RegistroProductosToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.RegistroProductosToolStripMenuItem.Text = "Registro Productos"
        '
        'COnsultasToolStripMenuItem
        '
        Me.COnsultasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsultaInventarioToolStripMenuItem})
        Me.COnsultasToolStripMenuItem.Name = "COnsultasToolStripMenuItem"
        Me.COnsultasToolStripMenuItem.Size = New System.Drawing.Size(71, 22)
        Me.COnsultasToolStripMenuItem.Text = "Consultas"
        '
        'ConsultaInventarioToolStripMenuItem
        '
        Me.ConsultaInventarioToolStripMenuItem.Name = "ConsultaInventarioToolStripMenuItem"
        Me.ConsultaInventarioToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.ConsultaInventarioToolStripMenuItem.Text = "Consulta Inventario"
        '
        'PictureBoxLogo
        '
        Me.PictureBoxLogo.Image = Global.InventarioProductos.My.Resources.Resources.Gemini_Generated_Image_29f59w29f59w29f5
        Me.PictureBoxLogo.Location = New System.Drawing.Point(0, 35)
        Me.PictureBoxLogo.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.PictureBoxLogo.Name = "PictureBoxLogo"
        Me.PictureBoxLogo.Size = New System.Drawing.Size(678, 379)
        Me.PictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxLogo.TabIndex = 2
        Me.PictureBoxLogo.TabStop = False
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(679, 409)
        Me.Controls.Add(Me.PictureBoxLogo)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft YaHei UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "MainForm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inventario Ingenidea"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBoxLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents OperacionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalidaProductosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EntradaInventarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegistroToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegistroProductosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents COnsultasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaInventarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBoxLogo As PictureBox
End Class
