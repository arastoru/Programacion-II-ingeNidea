﻿Public Class ProductosForm

    Private Sub btnNuevo_Click(sender As Object, e As EventArgs) Handles btnNuevo.Click
        txtID.Text = "0"
        txtPrecio.Clear()
        txtProducto.Clear()
        txtStock.Text = "0"

        txtProducto.Focus()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        If txtID.Text = "0" Then
            Dim cmd As New OleDb.OleDbCommand("insert into productos(descripcion,precio,stock) values('" & txtProducto.Text & "','" & txtPrecio.Text & "','" & txtStock.Text & "')", Conexion)
            cmd.ExecuteNonQuery()

            LlenarGrid()

        Else
            Dim cmd As New OleDb.OleDbCommand("update productos set descripcion='" & txtProducto.Text & "',precio='" & txtPrecio.Text & "' where id=" & txtID.Text, Conexion)
            cmd.ExecuteNonQuery()

            LlenarGrid()
        End If
    End Sub

    Public Sub LlenarGrid()
        Dim da As New OleDb.OleDbDataAdapter("select * from productos where descripcion like'%" & txtBuscar.Text & "%'", Conexion)
        Dim ds As New DataSet
        da.Fill(ds)

        If ds.Tables(0).Rows.Count > 0 Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            DataGridView1.DataSource = Nothing
        End If
    End Sub

    Private Sub ProductosForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LlenarGrid()
    End Sub

    Private Sub txtBuscar_TextChanged(sender As Object, e As EventArgs) Handles txtBuscar.TextChanged
        LlenarGrid()
    End Sub


    Private Sub DataGridView1_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellEnter
        If DataGridView1.RowCount > 0 Then
            txtID.Text = DataGridView1.CurrentRow.Cells("ID").Value
            txtProducto.Text = DataGridView1.CurrentRow.Cells("DESCRIPCION").Value.ToString
            txtPrecio.Text = DataGridView1.CurrentRow.Cells("PRECIO").Value
            txtStock.Text = ProductoDisponible(txtID.Text)
        End If
    End Sub
End Class