﻿Module Conexiones

    Public Conexion As OleDb.OleDbConnection

    Public Sub ABrirCOnexion()

        Conexion = New OleDb.OleDbConnection(connectionString:="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=basedatos2002.mdb;")
        Conexion.Open()

    End Sub


    Public Function ProductoDisponible(ByVal IDPRODUCTO As Integer)
        Dim Entradas As Integer = 0
        Dim Salidas As Integer = 0

        Dim da As New OleDb.OleDbDataAdapter("select IIF(SUM(CANTIDAD) IS NULL,0,SUM(CANTIDAD)) AS CANTIDAD from entrada_productos where ID_PRODUCTO=" & IDPRODUCTO, Conexion)
        Dim ds As New DataSet
        da.Fill(ds)
        If ds.Tables(0).Rows.Count > 0 Then
            Entradas = ds.Tables(0).Rows(0).Item("CANTIDAD")
        End If

        da = New OleDb.OleDbDataAdapter("select IIF(SUM(CANTIDAD) IS NULL,0,SUM(CANTIDAD)) AS CANTIDAD from salida_productos where ID_PRODUCTO=" & IDPRODUCTO, Conexion)
        ds = New DataSet
        da.Fill(ds)
        If ds.Tables(0).Rows.Count > 0 Then
            Salidas = ds.Tables(0).Rows(0).Item("CANTIDAD")
        End If

        Return Entradas - Salidas

    End Function
End Module
