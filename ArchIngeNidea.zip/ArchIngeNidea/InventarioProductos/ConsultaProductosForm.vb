﻿Public Class ConsultaProductosForm

    Private Sub ConsultaProductosForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LlenarGrid()
    End Sub

    Public Sub LlenarGrid()
        Dim da As New OleDb.OleDbDataAdapter("select productos.id,productos.descripcion,productos.precio, " & _
                                             "((select IIF(SUM(CANTIDAD) IS NULL,0,SUM(CANTIDAD)) from entrada_productos where id_producto=productos.id) - (select IIF(SUM(CANTIDAD) IS NULL,0,SUM(CANTIDAD)) from salida_productos where id_producto=productos.id))  as stock,  " & _
                                             " (select IIF(SUM(CANTIDAD) IS NULL,0,SUM(CANTIDAD)) from entrada_productos where id_producto=productos.id) as EntradasTotales, " & _
                                            " (select IIF(SUM(CANTIDAD) IS NULL,0,SUM(CANTIDAD)) from salida_productos where id_producto=productos.id) as SalidasTotales " & _
                                            "from productos  where productos.descripcion like'%" & txtBuscar.Text & "%'", Conexion)
        Dim ds As New DataSet
        da.Fill(ds)

        If ds.Tables(0).Rows.Count > 0 Then
            DataGridView1.DataSource = ds.Tables(0)
        Else
            DataGridView1.DataSource = Nothing
        End If
    End Sub

    Private Sub txtBuscar_TextChanged(sender As Object, e As EventArgs) Handles txtBuscar.TextChanged
        LlenarGrid()
    End Sub

    Private Sub btnSeleccionar_Click(sender As Object, e As EventArgs) Handles btnSeleccionar.Click
        If DataGridView1.RowCount > 0 Then
            SalidaProductosForm.txtProducto.Text = DataGridView1.CurrentRow.Cells("DESCRIPCION").Value.ToString
            SalidaProductosForm.txtID.Text = DataGridView1.CurrentRow.Cells("ID").Value
            SalidaProductosForm.txtPrecio.Text = DataGridView1.CurrentRow.Cells("PRECIO").Value.ToString
            SalidaProductosForm.txtStock.Text = DataGridView1.CurrentRow.Cells("stock").Value

            Me.Hide()
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class