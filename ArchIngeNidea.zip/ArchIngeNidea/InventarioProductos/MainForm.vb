﻿Public Class MainForm

    Private Sub COnsultasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles COnsultasToolStripMenuItem.Click

    End Sub

    Private Sub ConsultaInventarioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultaInventarioToolStripMenuItem.Click
        ConsultaProductosForm.Show()
    End Sub

    Private Sub RegistroProductosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistroProductosToolStripMenuItem.Click
        ProductosForm.Show()
    End Sub

    Private Sub SalidaProductosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalidaProductosToolStripMenuItem.Click
        SalidaProductosForm.Show()
    End Sub

    Private Sub EntradaInventarioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EntradaInventarioToolStripMenuItem.Click
        EntradaProductosForm.Show()
    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ABrirCOnexion()
    End Sub
End Class
