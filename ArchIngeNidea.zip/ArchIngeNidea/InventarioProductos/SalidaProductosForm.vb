﻿Public Class SalidaProductosForm

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        DataGridView1.Rows.Add(New String() {txtID.Text, txtProducto.Text, txtCantidad.Text})
        DataGridView1.EndEdit()

    End Sub

    Private Sub btnSalida_Click(sender As Object, e As EventArgs) Handles btnSalida.Click
        If MessageBox.Show("¿Seguro que desea procesar estos productos?", "Atencion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = vbYes Then


            For Each fila As DataGridViewRow In DataGridView1.Rows
                Dim Motivo As String = ""

                If CheckBox1.Checked = True Then
                    Motivo = "VENTA"
                ElseIf CheckBox2.Checked = True Then
                    Motivo = "PERDIDA"
                End If


                If fila.Cells(0).Value IsNot Nothing Then
                    Dim cmd As New OleDb.OleDbCommand("insert into salida_productos(fecha,id_producto,cantidad,motivo,id_factura) values(@fecha,'" & fila.Cells(0).Value & "','" & fila.Cells(2).Value.ToString & "','" & Motivo & "','" & txtFactura.Text & "')", Conexion)
                    cmd.Parameters.Add("@fecha", OleDb.OleDbType.Date).Value = Today.Date
                    cmd.ExecuteNonQuery()


                End If
            Next

            DataGridView1.Rows.Clear()


        End If

    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        ConsultaProductosForm.Show()
    End Sub

    Private Sub SalidaProductosForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub txtFactura_TextChanged(sender As Object, e As EventArgs) Handles txtFactura.TextChanged

    End Sub
End Class
